# This script generates Figure 1 in the manuscript,
# showing modeled versus measured H and LE at half-hourly, hourly, daily, weekly, and monthly timescales.

library(ggplot2)
library(gridExtra)
library(cowplot)
library(ggpubr)
library(Metrics)
library(ggpmisc)


# Load the results files at each temporal scales. (e.g.,"xxx.csv")
halfhourly <- read.csv("halfhourly.csv")
hourly <- read.csv("hourly.csv")
daily <- read.csv("daily.csv")
weekly <- read.csv("weekly.csv")
monthly <- read.csv("monthly.csv")


# Calculate RMSE for H and LE at each temporal scale
rmse_H_halfhourly <-rmse(halfhourly$measured_H,halfhourly$H)
rmse_H_halfhourly

rmse_LE_halfhourly <-rmse(halfhourly$measured_LE,halfhourly$LE)
rmse_LE_halfhourly

rmse_H_hourly <-rmse(hourly$measured_H,hourly$H)
rmse_H_hourly

rmse_LE_hourly <-rmse(hourly$measured_LE,hourly$LE)
rmse_LE_hourly

rmse_H_daily <-rmse(daily$measured_H,daily$H)
rmse_H_daily

rmse_LE_daily <-rmse(daily$measured_LE,daily$LE)
rmse_LE_daily

rmse_H_weekly <-rmse(weekly$measured_H,weekly$H)
rmse_H_weekly

rmse_LE_weekly <-rmse(weekly$measured_LE,weekly$LE)
rmse_LE_weekly

rmse_H_monthly <-rmse(monthly$measured_H,monthly$H)
rmse_H_monthly

rmse_LE_monthly <-rmse(monthly$measured_LE,monthly$LE)
rmse_LE_monthly



# Create a scatter plot. The two libraries can only be loaded here, otherwise some functions may contracdict to the functions from other libraries.
library(MASS)
library(viridis)

# The density function was copied from https://slowkow.com/notes/ggplot2-color-by-density/. 
# Get density of points in 2 dimensions.
# @param x A numeric vector.
# @param y A numeric vector.
# @param n Create a square n by n grid to compute density.
# @return The density within each square.
get_density <- function(x, y, ...) {
  dens <- MASS::kde2d(x, y, ...)
  ix <- findInterval(x, dens$x)
  iy <- findInterval(y, dens$y)
  ii <- cbind(ix, iy)
  return(dens$z[ii])
}


halfhourly$density_H <- get_density(halfhourly$measured_H,halfhourly$H,n=100)
halfhourly$density_LE <- get_density(halfhourly$measured_LE,halfhourly$LE,n=100)

halfhourly_H <- ggplot(halfhourly, aes(x = measured_H, y = H)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_H))+scale_color_viridis(option="C")+
  labs(title = "Half-hourly", color = "Density")+xlab(expression(H["obs"] ~(W~m^-2))) + ylab(expression(H ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_H_halfhourly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
halfhourly_H

halfhourly_LE <- ggplot(halfhourly, aes(x = measured_LE, y = LE)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_LE))+scale_color_viridis(option="C")+
  labs(title = "Half-hourly", color = "Density")+xlab(expression(LE["obs"] ~(W~m^-2))) + ylab(expression(LE ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_LE_halfhourly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

halfhourly_LE

hourly$density_H <- get_density(hourly$measured_H,hourly$H,n=100)
hourly$density_LE <- get_density(hourly$measured_LE,hourly$LE,n=100)

hourly_H <- ggplot(hourly, aes(x = measured_H, y = H)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_H))+scale_color_viridis(option="C")+
  labs(title = "Hourly", color = "Density")+xlab(expression(H["obs"] ~(W~m^-2))) + ylab(expression(H ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_H_hourly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
hourly_H

hourly_LE <- ggplot(hourly, aes(x = measured_LE, y = LE)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_LE))+scale_color_viridis(option="C")+
  labs(title = "Hourly", color = "Density")+xlab(expression(LE["obs"] ~(W~m^-2))) + ylab(expression(LE ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_LE_hourly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

hourly_LE

daily$density_H <- get_density(daily$measured_H,daily$H,n=100)
daily$density_LE <- get_density(daily$measured_LE,daily$LE,n=100)

daily_H <- ggplot(daily, aes(x = measured_H, y = H)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_H))+scale_color_viridis(option="C")+
  labs(title = "Daily", color = "Density")+xlab(expression(H["obs"] ~(W~m^-2))) + ylab(expression(H ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,250)+xlim(-50,250)+
  geom_text(x = 4, y = 214, label = paste("RMSE =", round(rmse_H_daily, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

daily_H


daily_LE <- ggplot(daily, aes(x = measured_LE, y = LE)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_LE))+scale_color_viridis(option="C")+
  labs(title = "Daily", color = "Density")+xlab(expression(LE["obs"] ~(W~m^-2))) + ylab(expression(LE ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,250)+xlim(-50,250)+
  geom_text(x = 4, y = 214, label = paste("RMSE =", round(rmse_LE_daily, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

daily_LE


weekly$density_H <- get_density(weekly$measured_H,weekly$H,n=100)
weekly$density_LE <- get_density(weekly$measured_LE,weekly$LE,n=100)

weekly_H <- ggplot(weekly, aes(x = measured_H, y = H)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_H))+scale_color_viridis(option="C")+
  labs(title = "Weekly", color = "Density")+xlab(expression(H["obs"] ~(W~m^-2))) + ylab(expression(H ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,200)+xlim(-50,200)+
  geom_text(x = -5, y = 170, label = paste("RMSE =", round(rmse_H_weekly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

weekly_H


weekly_LE <- ggplot(weekly, aes(x = measured_LE, y = LE)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_LE))+scale_color_viridis(option="C")+
  labs(title = "Weekly", color = "Density")+xlab(expression(LE["obs"] ~(W~m^-2))) + ylab(expression(LE ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,200)+xlim(-50,200)+
  geom_text(x = -5, y = 170, label = paste("RMSE =", round(rmse_LE_weekly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

weekly_LE


monthly$density_H <- get_density(monthly$measured_H,monthly$H,n=100)
monthly$density_LE <- get_density(monthly$measured_LE,monthly$LE,n=100)

monthly_H <- ggplot(monthly, aes(x = measured_H, y = H)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_H))+scale_color_viridis(option="C")+
  labs(title = "Monthly", color = "Density")+xlab(expression(H["obs"] ~(W~m^-2))) + ylab(expression(H ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,150)+xlim(-50,150)+
  geom_text(x = -14, y = 126, label = paste("RMSE =", round(rmse_H_monthly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

monthly_H


monthly_LE <- ggplot(monthly, aes(x = measured_LE, y = LE)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_LE))+scale_color_viridis(option="C")+
  labs(title = "Monthly", color = "Density")+xlab(expression(LE["obs"] ~(W~m^-2))) + ylab(expression(LE ~(W~m^-2)))+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,150)+xlim(-50,150)+
  geom_text(x = -14, y = 126, label = paste("RMSE =", round(rmse_LE_monthly, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

monthly_LE


# Combine the graphs
Figure_1 <- plot_grid(halfhourly_H,halfhourly_LE,hourly_H, hourly_LE, daily_H,daily_LE, weekly_H,weekly_LE,monthly_H,monthly_LE,nrow=5)
ggsave("Figure_1.tiff", device = "tiff",plot=Figure_1, dpi =800, width =8 , height =18,bg="white")
