# This script generates modelled sensible heat flux (H) and latent heat flux (LE) at the half-hourly timescale.
# Use soil moisture as an input variable

# Load required libraries
library(dplyr)
library(purrr)
library(lubridate)
library(ggplot2)
library(gridExtra)
library(cowplot)
library(ggpubr)
library(Metrics)
library(ggpmisc)

# Source the custom calculation functions (MaxEnt-ETRHEQ-WET)
source("method_theta.R")

#Import data from the US_BZB site
US_BZB <- read.csv("AMF_US-BZB_FLUXNET_FULLSET_HH_2011-2021_3-5.csv")

US_BZB <- US_BZB %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, H_CORR, LE_CORR,SWC_F_MDS_1,SWC_F_MDS_1_QC) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD,theta=SWC_F_MDS_1)

US_BZB <- US_BZB  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1),
         !(SWC_F_MDS_1_QC >1))

US_BZB <- US_BZB %>%
  mutate_all(~na_if(.,-9999))

US_BZB <- US_BZB  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100,
          theta = theta/100)

US_BZB$z <- 3 
US_BZB$zveg <- 0.5

US_BZB_input <- US_BZB[complete.cases(US_BZB), ]

US_BZB_input <- US_BZB_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_BZB_input

results_US_BZB <-Modelling_method_theta(data)

results_US_BZB <- cbind(US_BZB_input,results_US_BZB)

results_US_BZB <- results_US_BZB[complete.cases(results_US_BZB), ]


rmse_value_US_BZB_LE <-rmse(results_US_BZB$LE_F_MDS,results_US_BZB$LE)
rmse_value_US_BZB_LE
rmse_value_US_BZB_H <-rmse(results_US_BZB$H_F_MDS,results_US_BZB$H)
rmse_value_US_BZB_H

US_BZB_modelled_LE <-ggplot(results_US_BZB, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZB")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZB_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZB_modelled_LE

US_BZB_modelled_H <-ggplot(results_US_BZB, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZB")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_BZB_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZB_modelled_H

write.csv(results_US_BZB, "Results_US_BZB_theta.csv", row.names = FALSE)

#Import data from the US_BZF site
US_BZF <- read.csv("AMF_US-BZF_FLUXNET_FULLSET_HH_2011-2021_3-5.csv")

US_BZF <- US_BZF %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,H_CORR,LE_CORR,SWC_F_MDS_1,SWC_F_MDS_1_QC) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD,theta=SWC_F_MDS_1)

US_BZF <- US_BZF  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1),
         !(SWC_F_MDS_1_QC>1))  

US_BZF <- US_BZF %>%
  mutate_all(~na_if(.,-9999))

US_BZF <- US_BZF  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100,
          theta = theta/100)

US_BZF$z <- 2 
US_BZF$zveg <- 0.5

US_BZF_input <- US_BZF[complete.cases(US_BZF), ]

US_BZF_input <- US_BZF_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_BZF_input

results_US_BZF <-Modelling_method_theta(data)

results_US_BZF <- cbind(US_BZF_input,results_US_BZF)

results_US_BZF <- results_US_BZF[complete.cases(results_US_BZF), ]

rmse_value_US_BZF_LE <-rmse(results_US_BZF$LE_F_MDS,results_US_BZF$LE)
rmse_value_US_BZF_LE
rmse_value_US_BZF_H <-rmse(results_US_BZF$H_F_MDS,results_US_BZF$H)
rmse_value_US_BZF_H

US_BZF_modelled_LE <-ggplot(results_US_BZF, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZF")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +xlim(-100,750)+ylim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZF_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZF_modelled_LE

US_BZF_modelled_H <-ggplot(results_US_BZF, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZF")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +xlim(-100,500)+ylim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_BZF_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZF_modelled_H

write.csv(results_US_BZF, "Results_US_BZF_theta.csv", row.names = FALSE)

#Import data from the US_BZo site
US_BZo <- read.csv("AMF_US-BZo_FLUXNET_FULLSET_HH_2018-2021_3-5.csv")

US_BZo <- US_BZo %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, LE_CORR,H_CORR,SWC_F_MDS_1,SWC_F_MDS_1_QC) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD,theta=SWC_F_MDS_1)

US_BZo <- US_BZo  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1),
         !(SWC_F_MDS_1_QC >1))  

US_BZo <- US_BZo %>%
  mutate_all(~na_if(.,-9999))

US_BZo <- US_BZo  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100,
          theta = theta/100)

US_BZo$z <- 2.2 
US_BZo$zveg <- 0.5

US_BZo_input <- US_BZo[complete.cases(US_BZo), ]

US_BZo_input <- US_BZo_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_BZo_input

results_US_BZo <-Modelling_method_theta(data)

results_US_BZo <- cbind(US_BZo_input,results_US_BZo)

results_US_BZo <- results_US_BZo[complete.cases(results_US_BZo), ]

rmse_value_US_BZo_LE <-rmse(results_US_BZo$LE_F_MDS,results_US_BZo$LE)
rmse_value_US_BZo_LE
rmse_value_US_BZo_H <-rmse(results_US_BZo$H_F_MDS,results_US_BZo$H)
rmse_value_US_BZo_H

US_BZo_modelled_LE <-ggplot(results_US_BZo, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZo")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZo_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZo_modelled_LE

US_BZo_modelled_H <-ggplot(results_US_BZo, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZo")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZo_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZo_modelled_H

write.csv(results_US_BZo, "Results_US_BZo_theta.csv", row.names = FALSE)

#Import data from the US_ICs site
US_ICs <- read.csv("AMF_US-ICs_FLUXNET_FULLSET_HH_2007-2020_3-5.csv")

US_ICs <- US_ICs %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,LE_CORR,H_CORR,SWC_F_MDS_1,SWC_F_MDS_1_QC) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD,theta=SWC_F_MDS_1)

US_ICs <- US_ICs  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1),
         !(SWC_F_MDS_1_QC >1))  

US_ICs <- US_ICs %>%
  mutate_all(~na_if(.,-9999))

US_ICs <- US_ICs  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100,
          theta = theta/100)

US_ICs$z <- 2.56 
US_ICs$zveg <- 0.5

US_ICs_input <- US_ICs[complete.cases(US_ICs), ]

US_ICs_input <- US_ICs_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_ICs_input

results_US_ICs <-Modelling_method_theta(data)

results_US_ICs <- cbind(US_ICs_input,results_US_ICs)

results_US_ICs <- results_US_ICs[complete.cases(results_US_ICs), ]


rmse_value_US_ICs_LE <-rmse(results_US_ICs$LE_F_MDS,results_US_ICs$LE)
rmse_value_US_ICs_LE
rmse_value_US_ICs_H <-rmse(results_US_ICs$H_F_MDS,results_US_ICs$H)
rmse_value_US_ICs_H

US_ICs_modelled_LE <-ggplot(results_US_ICs, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_ICs")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_ICs_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_ICs_modelled_LE

US_ICs_modelled_H <-ggplot(results_US_ICs, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_ICs")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_ICs_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_ICs_modelled_H

write.csv(results_US_ICs, "Results_US_ICs_theta.csv", row.names = FALSE)

