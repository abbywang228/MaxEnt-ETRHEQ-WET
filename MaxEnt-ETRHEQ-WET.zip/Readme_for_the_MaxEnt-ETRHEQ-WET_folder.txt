The "MaxEnt-ETRHEQ-WET" directory contains two subfolders: Wetlands and Non-wetlands. The Wetlands and Non-wetlands subfolders contain R scripts for estimating surface energy fluxes and generating figures for the wetland and non-wetland sites presented in the manuscript.
##############

The Wetlands folder contains five subfolders. These subfolders are dedicated to modeling energy fluxes at five temporal resolutions—half-hourly, hourly, daily, weekly, and monthly.

In each timescale folder (except for the "Hourly" folder), there are four R scripts files:
- "method_ns.R" (MaxEnt-ETRHEQ-WET function to model H and LE, assuming constant soil thermal inertia (Is):1300 tiu)
- "method_theta.R" (MaxEnt-ETRHEQ function to model H and LE, using soil moisture (theta) to calculate Is.
- "timescale.R" (applying method_ns.R to wetland sites)
- "timescale_with_soil_moisture.R" (applying method_theta.R to wetland sites)

In the "Hourly" folder, there are two R scripts files:
- "Hourly_with_ERA5_friction_velocity.R" (MaxEnt-ETRHEQ-WET function to model sensible heat (H) and latent heat (LE) with ERA5 friction velocity data)
- "method_ns.R" (MaxEnt-ETRHEQ-WET function to model H and LE, assuming constant soil thermal inertia (Is):1300 tiu)

Additional, the Wetlands folder includes an R script named "Figure_1.R" which can be used to generate Figure 1 in the manuscript to show modelled versus measured H and LE at half-hourly, hourly, daily, weekly, and monthly timescales.


##############

The Non-Wetlands folder contains two R scripts files to estimate surface energy fluxes at both half-hourly and daily timescales for selected three non-wetland sites.

##############

Data at each time scale at each site are not provided. These datasets can be directly obtained from the FLUXNET and AmeriFlux websites. There is no need to reformat the downloaded dataset before executing the R scripts.
For each timescale, ensure that the four R scripts along with the corresponding data for that scale are placed within the same folder.

When executing the script for modeling half-hourly energy fluxes, the process may require up to 3-4 hours to complete for each site. However, for other time scales, the modeling typically takes less than 3 minutes for each site.

