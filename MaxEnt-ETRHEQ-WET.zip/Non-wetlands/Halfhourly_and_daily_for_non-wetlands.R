# This script generates modelled sensible heat flux (H) and latent heat flux (LE) at both half-hourly and daily timescales for non-wetlands sites.
# The modeling procedure is the same as that used for the wetland sites, except that in method_ns.R, an additional constraint (!is.na(zeta)) in Line 61 is added to avoid generating NA values in Kh.

#Load required libraries
library(dplyr)
library(purrr)
library(lubridate)
library(ggplot2)
library(gridExtra)
library(cowplot)
library(ggpubr)
library(Metrics)
library(ggpmisc)
library(grid)

# Source the custom calculation functions (MaxEnt-ETRHEQ-WET)
source("method_ns.R")

# Define a custom theme for publication-quality plots
theme_pub <- theme_bw(base_size = 12) +
  theme(
    plot.title = element_text(size = 12, face = "bold"),
    axis.text = element_text(size = 10),
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.border = element_rect(colour = "black", size = 1.2),
    axis.ticks = element_line(size = 1.2),
    panel.grid = element_blank(),
    legend.position = "none"
  )

#Half-hour scale
#Import data from the US_NGB site
US_NGB <- read.csv("AMF_US-NGB_FLUXNET_FULLSET_HH_2012-2019_3-5.csv")
US_NGB <- US_NGB %>% dplyr::select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH, NETRAD,G_F_MDS,G_F_MDS_QC,LE_F_MDS, LE_F_MDS_QC,H_F_MDS,H_F_MDS_QC, LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

US_NGB <- US_NGB  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1),
         !(RH > 100))

US_NGB <- US_NGB %>%
  mutate_all(~na_if(.,-9999))

US_NGB <- US_NGB  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_NGB$z <- 4.15 
US_NGB$zveg <- 0

US_NGB_input <- US_NGB[complete.cases(US_NGB), ]

US_NGB_input <- US_NGB_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_NGB_input

results_US_NGB <-Modelling_method_ns(data)

results_US_NGB <- cbind(US_NGB_input,results_US_NGB)

results_US_NGB <- results_US_NGB[complete.cases(results_US_NGB), ]

rmse_value_US_NGB_LE <-rmse(results_US_NGB$LE_F_MDS,results_US_NGB$LE)
rmse_value_US_NGB_LE
rmse_value_US_NGB_H <-rmse(results_US_NGB$H_F_MDS,results_US_NGB$H)
rmse_value_US_NGB_H

US_NGB_modelled_LE <-ggplot(results_US_NGB, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_NGB (Tundra)")+
  stat_poly_line(color="#dc267f") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,200)+xlim(-50,200)+
  geom_text(x = -5, y = 170, label = paste("RMSE =", round(rmse_value_US_NGB_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_NGB_modelled_LE

US_NGB_modelled_H <-ggplot(results_US_NGB, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_NGB (Tundra)")+
  stat_poly_line(color="#ffb000") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,150)+xlim(-50,150)+
  geom_text(x = -14, y = 126, label = paste("RMSE =", round(rmse_value_US_NGB_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_NGB_modelled_H

write.csv(results_US_NGB, "Results_US_NGB_all.csv", row.names = FALSE)

#Import data from the US_Goo site
US_Goo <- read.csv("FLX_US-Goo_FLUXNET2015_FULLSET_HH_2002-2006_1-4.csv")

US_Goo <- US_Goo %>% dplyr::select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH, NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

US_Goo <- US_Goo  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1 ),
         !(WS_F_QC >1 ),
         !(G_F_MDS_QC >1 ),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))

US_Goo <- US_Goo %>%
  mutate_all(~na_if(.,-9999))

US_Goo <- US_Goo  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_Goo$z <- 4 
US_Goo$zveg <- 0.35

US_Goo_input <- US_Goo[complete.cases(US_Goo), ]

US_Goo_input <- US_Goo_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_Goo_input

results_US_Goo <-Modelling_method_ns(data)

results_US_Goo <- cbind(US_Goo_input,results_US_Goo)

results_US_Goo <- results_US_Goo[complete.cases(results_US_Goo), ]

rmse_value_US_Goo_LE <-rmse(results_US_Goo$LE_F_MDS,results_US_Goo$LE)
rmse_value_US_Goo_LE
rmse_value_US_Goo_H <-rmse(results_US_Goo$H_F_MDS,results_US_Goo$H)
rmse_value_US_Goo_H

US_Goo_modelled_LE <-ggplot(results_US_Goo, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Goo (Grassland)")+
  stat_poly_line(color="#dc267f") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_Goo_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_Goo_modelled_LE

US_Goo_modelled_H <-ggplot(results_US_Goo, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Goo (Grassland)")+
  stat_poly_line(color="#ffb000") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_Goo_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_Goo_modelled_H

write.csv(results_US_Goo, "Results_US_Goo_all.csv", row.names = FALSE)

#Import data from the BR-Sa3 site
BR_Sa3 <- read.csv("FLX_BR-Sa3_FLUXNET2015_FULLSET_HH_2000-2004_1-4.csv")

BR_Sa3 <- BR_Sa3 %>% dplyr::select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH, NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

BR_Sa3 <- BR_Sa3  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

BR_Sa3 <- BR_Sa3 %>%
  mutate_all(~na_if(.,-9999))

BR_Sa3 <- BR_Sa3  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

BR_Sa3$z <- 64 
BR_Sa3$zveg <- 27.5

BR_Sa3_input <- BR_Sa3[complete.cases(BR_Sa3), ]

BR_Sa3_input <- BR_Sa3_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-BR_Sa3_input

results_BR_Sa3 <-Modelling_method_ns(data)

results_BR_Sa3 <- cbind(BR_Sa3_input,results_BR_Sa3)

results_BR_Sa3 <- results_BR_Sa3[complete.cases(results_BR_Sa3), ]

rmse_value_BR_Sa3_LE <-rmse(results_BR_Sa3$LE_F_MDS,results_BR_Sa3$LE)
rmse_value_BR_Sa3_LE
rmse_value_BR_Sa3_H <-rmse(results_BR_Sa3$H_F_MDS,results_BR_Sa3$H)
rmse_value_BR_Sa3_H

BR_Sa3_modelled_LE <-ggplot(results_BR_Sa3, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="BR_Sa3 (Forest)")+
  stat_poly_line(color="#dc267f") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_BR_Sa3_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
BR_Sa3_modelled_LE

BR_Sa3_modelled_H <-ggplot(results_BR_Sa3, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="BR_Sa3 (Forest)")+
  stat_poly_line(color="#ffb000") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_BR_Sa3_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
BR_Sa3_modelled_H

write.csv(results_BR_Sa3, "Results_BR_Sa3_all.csv", row.names = FALSE)


#Figure 4 top panel
#Figure 4 bottom panel
Model_LE_Figure4_1 <- plot_grid(BR_Sa3_modelled_LE,US_Goo_modelled_LE,US_NGB_modelled_LE,nrow=1)

# Create a title plot as a proper ggdraw object
Title_plot_1 <- ggdraw() + 
  draw_label("Half-hourly", fontface = 'bold', color = "#ffb000", size = 16, hjust = 0.5, x = 0.5)

# Combine title + plot row
Model_LE_Figure4_1_with_title <- plot_grid(
  Title_plot_1,
  Model_LE_Figure4_1,
  ncol = 1,
  rel_heights = c(0.1, 1)
)


#Daily scale

# Build a function to calculate RH from Ta and VPD
Calculate_RH <- function(Ta, VPD) {
  # Check for NA in inputs (vectorized)
  NA_indices <- is.na(Ta) | is.na(VPD)
  
  # Initialize RH, estar_Ta, and ea_Ta with NA values
  RH <- rep(NA, length(Ta))
  estar_Ta <- rep(NA, length(Ta))
  ea_Ta <- rep(NA, length(Ta))
  
  # Loop only non-NA values
  for (i in which(!NA_indices)) {
    
    estar_Ta[i] <-611.2*exp(17.67*(Ta[i]-273.15)/(Ta[i]-29.65)) # saturated vapor pressure (Pa)
    ea_Ta[i] <- estar_Ta[i]-VPD[i]
    RH[i] <-ea_Ta[i]/estar_Ta[i]
  }
  
  return(RH)
  
}

#Import data from the US_NGB site
US_NGB_Daily <- read.csv("AMF_US-NGB_FLUXNET_FULLSET_DD_2012-2019_3-5.csv")

US_NGB_Daily <- US_NGB_Daily %>%
  select(
    TIMESTAMP,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,USTAR_QC,VPD_F,VPD_F_QC, NETRAD,NETRAD_QC,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR, VPD=VPD_F,Rn=NETRAD)

US_NGB_Daily <- US_NGB_Daily  %>%
  filter(!(PA_F_QC >0 & PA_F_QC <0.8),
         !(TA_F_QC >0 & TA_F_QC <0.8),
         !(WS_F_QC >0 & WS_F_QC <0.8),
         !(USTAR_QC >0 & USTAR_QC <0.8),
         !(VPD_F_QC >0 & VPD_F_QC <0.8),
         !(NETRAD_QC >0 & NETRAD_QC <0.8),
         !(G_F_MDS_QC >0 & G_F_MDS_QC <0.8),
         !(LE_F_MDS_QC >0 & LE_F_MDS_QC <0.8),
         !(H_F_MDS_QC >0 & H_F_MDS_QC <0.8))  

US_NGB_Daily <- US_NGB_Daily %>%
  mutate_all(~na_if(.,-9999))

US_NGB_Daily <- US_NGB_Daily  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          VPD = VPD*100)

US_NGB_Daily$RH <- Calculate_RH(US_NGB_Daily$Ta,US_NGB_Daily$VPD)

US_NGB_Daily$z <- 4.15 
US_NGB_Daily$zveg <- 0

US_NGB_Daily_input <- US_NGB_Daily[complete.cases(US_NGB_Daily), ]

US_NGB_Daily_input <- US_NGB_Daily_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_NGB_Daily_input

results_US_NGB_Daily <-Modelling_method_ns(data)

results_US_NGB_Daily <- cbind(US_NGB_Daily_input,results_US_NGB_Daily)

results_US_NGB_Daily <- results_US_NGB_Daily[complete.cases(results_US_NGB_Daily), ]

rmse_value_US_NGB_Daily_LE <-rmse(results_US_NGB_Daily$LE_F_MDS,results_US_NGB_Daily$LE)
rmse_value_US_NGB_Daily_LE
rmse_value_US_NGB_Daily_H <-rmse(results_US_NGB_Daily$H_F_MDS,results_US_NGB_Daily$H)
rmse_value_US_NGB_Daily_H

US_NGB_Daily_modelled_LE <-ggplot(results_US_NGB_Daily, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_NGB (Tundra)")+
  stat_poly_line(color="#dc267f") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,250)+xlim(-100,250)+
  geom_text(x = -37, y = 208, label = paste("RMSE =", round(rmse_value_US_NGB_Daily_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_NGB_Daily_modelled_LE

US_NGB_Daily_modelled_H <-ggplot(results_US_NGB_Daily, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_NGB (Tundra)")+
  stat_poly_line(color="#ffb000") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,250)+xlim(-100,250)+
  geom_text(x = -37, y = 208, label = paste("RMSE =", round(rmse_value_US_NGB_Daily_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_NGB_Daily_modelled_H

write.csv(results_US_NGB_Daily, "Results_US_NGB_Daily_no_theta.csv", row.names = FALSE)


#Import data from the US_Goo site
US_Goo_Daily <- read.csv("FLX_US-Goo_FLUXNET2015_FULLSET_DD_2002-2006_1-4.csv")

US_Goo_Daily <- US_Goo_Daily %>%
  select(
    TIMESTAMP,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,USTAR_QC,VPD_F,VPD_F_QC, NETRAD,NETRAD_QC,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR, VPD=VPD_F,Rn=NETRAD)

US_Goo_Daily <- US_Goo_Daily  %>%
  filter(!(PA_F_QC >0 & PA_F_QC <0.8),
         !(TA_F_QC >0 & TA_F_QC <0.8),
         !(WS_F_QC >0 & WS_F_QC <0.8),
         !(USTAR_QC >0 & USTAR_QC <0.8),
         !(VPD_F_QC >0 & VPD_F_QC <0.8),
         !(NETRAD_QC >0 & NETRAD_QC <0.8),
         !(G_F_MDS_QC >0 & G_F_MDS_QC <0.8),
         !(LE_F_MDS_QC >0 & LE_F_MDS_QC <0.8),
         !(H_F_MDS_QC >0 & H_F_MDS_QC <0.8))  

US_Goo_Daily <- US_Goo_Daily %>%
  mutate_all(~na_if(.,-9999))

US_Goo_Daily <- US_Goo_Daily  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          VPD = VPD*100)

US_Goo_Daily$RH <- Calculate_RH(US_Goo_Daily$Ta,US_Goo_Daily$VPD)

US_Goo_Daily$z <- 4 
US_Goo_Daily$zveg <- 0.35

US_Goo_Daily_input <- US_Goo_Daily[complete.cases(US_Goo_Daily), ]

US_Goo_Daily_input <- US_Goo_Daily_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-US_Goo_Daily_input

results_US_Goo_Daily <-Modelling_method_ns(data)

results_US_Goo_Daily <- cbind(US_Goo_Daily_input,results_US_Goo_Daily)

results_US_Goo_Daily <- results_US_Goo_Daily[complete.cases(results_US_Goo_Daily), ]

rmse_value_US_Goo_Daily_LE <-rmse(results_US_Goo_Daily$LE_F_MDS,results_US_Goo_Daily$LE)
rmse_value_US_Goo_Daily_LE
rmse_value_US_Goo_Daily_H <-rmse(results_US_Goo_Daily$H_F_MDS,results_US_Goo_Daily$H)
rmse_value_US_Goo_Daily_H

US_Goo_Daily_modelled_LE <-ggplot(results_US_Goo_Daily, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Goo (Grassland)")+
  stat_poly_line(color="#dc267f") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,250)+xlim(-100,250)+
  geom_text(x = -37, y = 208, label = paste("RMSE =", round(rmse_value_US_Goo_Daily_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_Goo_Daily_modelled_LE

US_Goo_Daily_modelled_H <-ggplot(results_US_Goo_Daily, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Goo (Grassland)")+
  stat_poly_line(color="#ffb000") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,250)+xlim(-100,250)+
  geom_text(x = -37, y = 208, label = paste("RMSE =", round(rmse_value_US_Goo_Daily_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
US_Goo_Daily_modelled_H

write.csv(results_US_Goo_Daily, "Results_US_Goo_Daily_no_theta.csv", row.names = FALSE)


#Import data from the BR_Sa3 site
BR_Sa3_Daily <- read.csv("FLX_BR-Sa3_FLUXNET2015_FULLSET_DD_2000-2004_1-4.csv")

BR_Sa3_Daily <- BR_Sa3_Daily %>%
  select(
    TIMESTAMP,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,USTAR_QC,VPD_F,VPD_F_QC, NETRAD,NETRAD_QC,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR, VPD=VPD_F,Rn=NETRAD)

BR_Sa3_Daily <- BR_Sa3_Daily  %>%
  filter(!(PA_F_QC >0 & PA_F_QC <0.8),
         !(TA_F_QC >0 & TA_F_QC <0.8),
         !(WS_F_QC >0 & WS_F_QC <0.8),
         !(USTAR_QC >0 & USTAR_QC <0.8),
         !(VPD_F_QC >0 & VPD_F_QC <0.8),
         !(NETRAD_QC >0 & NETRAD_QC <0.8),
         !(G_F_MDS_QC >0 & G_F_MDS_QC <0.8),
         !(LE_F_MDS_QC >0 & LE_F_MDS_QC <0.8),
         !(H_F_MDS_QC >0 & H_F_MDS_QC <0.8))  

BR_Sa3_Daily <- BR_Sa3_Daily %>%
  mutate_all(~na_if(.,-9999))

BR_Sa3_Daily <- BR_Sa3_Daily  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          VPD = VPD*100)

BR_Sa3_Daily$RH <- Calculate_RH(BR_Sa3_Daily$Ta,BR_Sa3_Daily$VPD)

BR_Sa3_Daily$z <- 64 
BR_Sa3_Daily$zveg <- 27.5

BR_Sa3_Daily_input <- BR_Sa3_Daily[complete.cases(BR_Sa3_Daily), ]

BR_Sa3_Daily_input <- BR_Sa3_Daily_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

data <-BR_Sa3_Daily_input

results_BR_Sa3_Daily <-Modelling_method_ns(data)

results_BR_Sa3_Daily <- cbind(BR_Sa3_Daily_input,results_BR_Sa3_Daily)

results_BR_Sa3_Daily <- results_BR_Sa3_Daily[complete.cases(results_BR_Sa3_Daily), ]

rmse_value_BR_Sa3_Daily_LE <-rmse(results_BR_Sa3_Daily$LE_F_MDS,results_BR_Sa3_Daily$LE)
rmse_value_BR_Sa3_Daily_LE
rmse_value_BR_Sa3_Daily_H <-rmse(results_BR_Sa3_Daily$H_F_MDS,results_BR_Sa3_Daily$H)
rmse_value_BR_Sa3_Daily_H

BR_Sa3_Daily_modelled_LE <-ggplot(results_BR_Sa3_Daily, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="BR_Sa3 (Forest)")+
  stat_poly_line(color="#dc267f") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,250)+xlim(-100,250)+
  geom_text(x = -37, y = 208, label = paste("RMSE =", round(rmse_value_BR_Sa3_Daily_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
BR_Sa3_Daily_modelled_LE

BR_Sa3_Daily_modelled_H <-ggplot(results_BR_Sa3_Daily, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="#648fff")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="BR_Sa3 (Forest)")+
  stat_poly_line(color="#ffb000") +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,250)+xlim(-100,250)+
  geom_text(x = -37, y = 208, label = paste("RMSE =", round(rmse_value_BR_Sa3_Daily_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_pub
BR_Sa3_Daily_modelled_H

write.csv(results_BR_Sa3_Daily, "Results_BR_Sa3_Daily_no_theta.csv", row.names = FALSE)


#Figure 4 bottom panel
Model_LE_Figure4_2 <- plot_grid(
  BR_Sa3_Daily_modelled_LE,
  US_Goo_Daily_modelled_LE,
  US_NGB_Daily_modelled_LE,
  nrow = 1
)

# Create a title plot as a proper ggdraw object
Title_plot_2 <- ggdraw() + 
  draw_label("Daily", fontface = 'bold', color = "#ffb000", size = 16, hjust = 0.5, x = 0.5)

# Combine title + plot row
Model_LE_Figure4_2_with_title <- plot_grid(
  Title_plot_2,
  Model_LE_Figure4_2,
  ncol = 1,
  rel_heights = c(0.1, 1)
)

Model_LE_Figure4 <- plot_grid(Model_LE_Figure4_1_with_title, Model_LE_Figure4_2_with_title, nrow=2)

Figure_LE_Figure4 <- annotate_figure(Model_LE_Figure4, left = textGrob(expression("Modelled LE"~(W~m^-2)), rot = 90, gp = gpar(cex = 1.3)),
                                      bottom = textGrob(expression("Measured LE"~(W~m^-2)), gp = gpar(cex = 1.3)))
ggsave("Figure_4.tiff", device = "tiff",plot=Figure_LE_Figure4, dpi =800, width =12 , height =8,bg="white")


