# Load library
library(ggOceanMaps) # in order to use its function dis2land, the output are in kilometers.
library(rnaturalearth)
library(sf)

# Load coastline data
coast <- ne_coastline(scale=10, returnclass = "sf")

# Load the study site coordinates
Global_sites <- read.csv("Global_sites.csv")

# Calculate the shortest distance
ggOceanMaps::dist2land(Global_sites,shapefile =coast)

# Load the non-wetland site coordinates
Additional_sites <- read.csv("Additional_non-wetland_sites.csv")

# Calculate the shortest distance for the non-wetland sites
ggOceanMaps::dist2land(Additional_sites,shapefile =coast)
