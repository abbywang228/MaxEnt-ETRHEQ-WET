#The following script provides the modelled H and LE at subdaily scale.
#No soil moisture (theta) is needed.

#Load essental libraries
library(dplyr)
library(purrr)
library(lubridate)
library(ggplot2)
library(gridExtra)
library(cowplot)
library(ggpubr)
library(Metrics)
library(ggpmisc)

# Load the calculation method
source("method_ns.R")

#Import data from CZ_wet site
CZ_wet <- read.csv("FLX_CZ-wet_FLUXNET2015_FULLSET_HH_2006-2014_1-4.csv")
CZ_wet <- CZ_wet %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH, NETRAD,G_F_MDS,G_F_MDS_QC,LE_F_MDS, LE_F_MDS_QC,H_F_MDS,H_F_MDS_QC, LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

CZ_wet <- CZ_wet  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))

#Set the NA values
CZ_wet <- CZ_wet %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
CZ_wet <- CZ_wet  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

CZ_wet$z <- 2.6 
CZ_wet$zveg <- 1

# Remove the NA values
CZ_wet_input <- CZ_wet[complete.cases(CZ_wet), ]

#Remove the energy unclosure data
CZ_wet_input <- CZ_wet_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-CZ_wet_input

# Modelling using method_ns
results_CZ_wet <-Modelling_method_ns(data)
results_CZ_wet <- cbind(CZ_wet_input,results_CZ_wet)

# Remove the NA values in the results
results_CZ_wet <- results_CZ_wet[complete.cases(results_CZ_wet), ]

# Ploting
rmse_value_CZ_wet_LE <-rmse(results_CZ_wet$LE_F_MDS,results_CZ_wet$LE)
rmse_value_CZ_wet_LE

rmse_value_CZ_wet_H <-rmse(results_CZ_wet$H_F_MDS,results_CZ_wet$H)
rmse_value_CZ_wet_H

CZ_wet_modelled_LE <-ggplot(results_CZ_wet, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="CZ_wet")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,200)+xlim(-50,200)+
  geom_text(x = -5, y = 170, label = paste("RMSE =", round(rmse_value_CZ_wet_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
CZ_wet_modelled_LE

CZ_wet_modelled_H <-ggplot(results_CZ_wet, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="CZ_wet")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-50,150)+xlim(-50,150)+
  geom_text(x = -14, y = 126, label = paste("RMSE =", round(rmse_value_CZ_wet_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
CZ_wet_modelled_H

#Save the results
write.csv(results_CZ_wet, "Results_CZ_wet_all.csv", row.names = FALSE)

#Import data from DE_sfN site
DE_sfN <- read.csv("FLX_DE-SfN_FLUXNET2015_FULLSET_HH_2012-2014_1-4.csv")

DE_sfN <- DE_sfN %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH, NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
DE_sfN <- DE_sfN  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1 ),
         !(WS_F_QC >1 ),
         !(G_F_MDS_QC >1 ),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))

#Set the NA values
DE_sfN <- DE_sfN %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
DE_sfN <- DE_sfN  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

DE_sfN$z <- 6.7 
DE_sfN$zveg <- 2

# Remove the NA values
DE_sfN_input <- DE_sfN[complete.cases(DE_sfN), ]

#Remove the energy unclosure data
DE_sfN_input <- DE_sfN_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-DE_sfN_input

# Modelling using method_ns
results_DE_sfN <-Modelling_method_ns(data)
results_DE_sfN <- cbind(DE_sfN_input,results_DE_sfN)

# Remove the NA values in the results
results_DE_sfN <- results_DE_sfN[complete.cases(results_DE_sfN), ]

# Ploting
rmse_value_DE_sfN_LE <-rmse(results_DE_sfN$LE_F_MDS,results_DE_sfN$LE)
rmse_value_DE_sfN_LE

rmse_value_DE_sfN_H <-rmse(results_DE_sfN$H_F_MDS,results_DE_sfN$H)
rmse_value_DE_sfN_H

DE_sfN_modelled_LE <-ggplot(results_DE_sfN, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="DE_sfN")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_DE_sfN_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
DE_sfN_modelled_LE

DE_sfN_modelled_H <-ggplot(results_DE_sfN, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="DE_sfN")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_DE_sfN_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
DE_sfN_modelled_H

#Save the results
write.csv(results_DE_sfN, "Results_DE_sfN_all.csv", row.names = FALSE)

#Import data from DE_Zrk site
DE_Zrk <- read.csv("FLX_DE-Zrk_FLUXNET2015_FULLSET_HH_2013-2014_2-4.csv")

DE_Zrk <- DE_Zrk %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH, NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
DE_Zrk <- DE_Zrk  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

#Set the NA values
DE_Zrk <- DE_Zrk %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
DE_Zrk <- DE_Zrk  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

DE_Zrk$z <- 2.7 
DE_Zrk$zveg <- 0

# Remove the NA values 
DE_Zrk_input <- DE_Zrk[complete.cases(DE_Zrk), ]

#Remove the energy unclosure data
DE_Zrk_input <- DE_Zrk_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-DE_Zrk_input

# Modelling using method_ns
results_DE_Zrk <-Modelling_method_ns(data)
results_DE_Zrk <- cbind(DE_Zrk_input,results_DE_Zrk)

# Remove the NA values of the results
results_DE_Zrk <- results_DE_Zrk[complete.cases(results_DE_Zrk), ]

# Ploting
rmse_value_DE_Zrk_LE <-rmse(results_DE_Zrk$LE_F_MDS,results_DE_Zrk$LE)
rmse_value_DE_Zrk_LE

rmse_value_DE_Zrk_H <-rmse(results_DE_Zrk$H_F_MDS,results_DE_Zrk$H)
rmse_value_DE_Zrk_H

DE_Zrk_modelled_LE <-ggplot(results_DE_Zrk, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="DE_Zrk")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_DE_Zrk_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
DE_Zrk_modelled_LE

DE_Zrk_modelled_H <-ggplot(results_DE_Zrk, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="DE_Zrk")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_DE_Zrk_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
DE_Zrk_modelled_H

#Save the results
write.csv(results_DE_Zrk, "Results_DE_Zrk_all.csv", row.names = FALSE)


#Import data from FI_Lom site
FI_Lom <- read.csv("FLX_FI-Lom_FLUXNET2015_FULLSET_HH_2007-2009_1-4.csv")
FI_Lom <- FI_Lom %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,LE_F_MDS,LE_F_MDS_QC,H_F_MDS,H_F_MDS_QC,H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

FI_Lom<- FI_Lom  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1),
         !(G_F_MDS_QC >1))

#Set the NA values
FI_Lom <- FI_Lom %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
FI_Lom <- FI_Lom  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

FI_Lom$z <- 3 
FI_Lom$zveg <- 0.45

# Remove the NA values
FI_Lom_input <- FI_Lom[complete.cases(FI_Lom), ]

#Remove the energy unclosure data
FI_Lom_input <- FI_Lom_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-FI_Lom_input

# Modelling using method_ns
results_FI_Lom <-Modelling_method_ns(data)
results_FI_Lom <- cbind(FI_Lom_input,results_FI_Lom)

# Remove the NA values in the results
results_FI_Lom <- results_FI_Lom[complete.cases(results_FI_Lom), ]

# Ploting
rmse_value_FI_Lom_LE <-rmse(results_FI_Lom$LE_F_MDS,results_FI_Lom$LE)
rmse_value_FI_Lom_LE

rmse_value_FI_Lom_H <-rmse(results_FI_Lom$H_F_MDS,results_FI_Lom$H)
rmse_value_FI_Lom_H

FI_Lom_modelled_LE <-ggplot(results_FI_Lom, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="FI_Lom")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_FI_Lom_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
FI_Lom_modelled_LE

FI_Lom_modelled_H <-ggplot(results_FI_Lom, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="FI_Lom")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_FI_Lom_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
FI_Lom_modelled_H

#Save the results
write.csv(results_FI_Lom, "Results_FI_Lom_all.csv", row.names = FALSE)


#Import data from US_Atq site
US_Atq <- read.csv("FLX_US-Atq_FLUXNET2015_FULLSET_HH_2003-2008_1-4.csv")

US_Atq <- US_Atq %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
US_Atq <- US_Atq  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

#Set the NA values
US_Atq <- US_Atq  %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
US_Atq <- US_Atq  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_Atq$z <- 2.42 
US_Atq$zveg <- 0.3

# Remove the NA values
US_Atq_input <- US_Atq[complete.cases(US_Atq), ]

#Remove the energy unclosure data
US_Atq_input <- US_Atq_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-US_Atq_input

# Modelling using method_ns
results_US_Atq <-Modelling_method_ns(data)
results_US_Atq <- cbind(US_Atq_input,results_US_Atq)

# Remove the NA values in the results
results_US_Atq <- results_US_Atq[complete.cases(results_US_Atq), ]

# Ploting
rmse_value_US_Atq_LE <-rmse(results_US_Atq$LE_F_MDS,results_US_Atq$LE)
rmse_value_US_Atq_LE

rmse_value_US_Atq_H <-rmse(results_US_Atq$H_F_MDS,results_US_Atq$H)
rmse_value_US_Atq_H

US_Atq_modelled_LE <-ggplot(results_US_Atq, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Atq")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_Atq_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_Atq_modelled_LE

US_Atq_modelled_H <-ggplot(results_US_Atq, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Atq")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_Atq_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_Atq_modelled_H

#Save the results
write.csv(results_US_Atq, "Results_US_Atq_all.csv", row.names = FALSE)

#Import data from US_BZB site
US_BZB <- read.csv("AMF_US-BZB_FLUXNET_FULLSET_HH_2011-2021_3-5.csv")

US_BZB <- US_BZB %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, H_CORR, LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
US_BZB <- US_BZB  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))


#Set the NA values
US_BZB <- US_BZB %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
US_BZB <- US_BZB  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_BZB$z <- 3 
US_BZB$zveg <- 0.5

# Remove the NA values
US_BZB_input <- US_BZB[complete.cases(US_BZB), ]

#Remove the energy unclosure data
US_BZB_input <- US_BZB_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-US_BZB_input

# Modelling using method_ns
results_US_BZB <-Modelling_method_ns(data)
results_US_BZB <- cbind(US_BZB_input,results_US_BZB)

# Remove the NA values in the results
results_US_BZB <- results_US_BZB[complete.cases(results_US_BZB), ]

# Ploting
rmse_value_US_BZB_LE <-rmse(results_US_BZB$LE_F_MDS,results_US_BZB$LE)
rmse_value_US_BZB_LE

rmse_value_US_BZB_H <-rmse(results_US_BZB$H_F_MDS,results_US_BZB$H)
rmse_value_US_BZB_H

US_BZB_modelled_LE <-ggplot(results_US_BZB, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZB")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZB_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZB_modelled_LE

US_BZB_modelled_H <-ggplot(results_US_BZB, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZB")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_BZB_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZB_modelled_H

#Save the results
write.csv(results_US_BZB, "Results_US_BZB_all.csv", row.names = FALSE)

#Import data from US_BZF site
US_BZF <- read.csv("AMF_US-BZF_FLUXNET_FULLSET_HH_2011-2021_3-5.csv")

US_BZF <- US_BZF %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
US_BZF <- US_BZF  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

#Set the NA values
US_BZF <- US_BZF %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
US_BZF <- US_BZF  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_BZF$z <- 2 
US_BZF$zveg <- 0.5

# Remove the NA values
US_BZF_input <- US_BZF[complete.cases(US_BZF), ]

#Remove the energy unclosure data
US_BZF_input <- US_BZF_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-US_BZF_input

# Modelling using method_ns
results_US_BZF <-Modelling_method_ns(data)
results_US_BZF <- cbind(US_BZF_input,results_US_BZF)

# Remove the NA values in the results
results_US_BZF <- results_US_BZF[complete.cases(results_US_BZF), ]

# Ploting
rmse_value_US_BZF_LE <-rmse(results_US_BZF$LE_F_MDS,results_US_BZF$LE)
rmse_value_US_BZF_LE

rmse_value_US_BZF_H <-rmse(results_US_BZF$H_F_MDS,results_US_BZF$H)
rmse_value_US_BZF_H

US_BZF_modelled_LE <-ggplot(results_US_BZF, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZF")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +xlim(-100,750)+ylim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZF_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZF_modelled_LE

US_BZF_modelled_H <-ggplot(results_US_BZF, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZF")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +xlim(-100,500)+ylim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_BZF_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZF_modelled_H

#Save the results
write.csv(results_US_BZF, "Results_US_BZF_all.csv", row.names = FALSE)

#Import data from US_BZo site
US_BZo <- read.csv("AMF_US-BZo_FLUXNET_FULLSET_HH_2018-2021_3-5.csv")

US_BZo <- US_BZo %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
US_BZo <- US_BZo  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

#Set the NA values
US_BZo <- US_BZo %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
US_BZo <- US_BZo  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_BZo$z <- 2.2 
US_BZo$zveg <- 0.5

# Remove the NA values
US_BZo_input <- US_BZo[complete.cases(US_BZo), ]

#Remove the energy unclosure data
US_BZo_input <- US_BZo_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-US_BZo_input

# Modelling using method_ns
results_US_BZo <-Modelling_method_ns(data)
results_US_BZo <- cbind(US_BZo_input,results_US_BZo)

# Remove the NA values
results_US_BZo <- results_US_BZo[complete.cases(results_US_BZo), ]

# Ploting
rmse_value_US_BZo_LE <-rmse(results_US_BZo$LE_F_MDS,results_US_BZo$LE)
rmse_value_US_BZo_LE

rmse_value_US_BZo_H <-rmse(results_US_BZo$H_F_MDS,results_US_BZo$H)
rmse_value_US_BZo_H

US_BZo_modelled_LE <-ggplot(results_US_BZo, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZo")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZo_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZo_modelled_LE

US_BZo_modelled_H <-ggplot(results_US_BZo, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_BZo")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_BZo_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_BZo_modelled_H

#Save the results
write.csv(results_US_BZo, "Results_US_BZo_all.csv", row.names = FALSE)

#Import data from US_ICs site
US_ICs <- read.csv("AMF_US-ICs_FLUXNET_FULLSET_HH_2007-2020_3-5.csv")

US_ICs <- US_ICs %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
US_ICs <- US_ICs  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

#Set the NA values
US_ICs <- US_ICs %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
US_ICs <- US_ICs  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_ICs$z <- 2.56 
US_ICs$zveg <- 0.5

# Remove the NA values
US_ICs_input <- US_ICs[complete.cases(US_ICs), ]

#Remove the energy unclosure data
US_ICs_input <- US_ICs_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))

# Assign the dataframe for model input
data <-US_ICs_input

# Modelling using method_ns
results_US_ICs <-Modelling_method_ns(data)
results_US_ICs <- cbind(US_ICs_input,results_US_ICs)

# Remove the NA values in the results
results_US_ICs <- results_US_ICs[complete.cases(results_US_ICs), ]

# Ploting
rmse_value_US_ICs_LE <-rmse(results_US_ICs$LE_F_MDS,results_US_ICs$LE)
rmse_value_US_ICs_LE

rmse_value_US_ICs_H <-rmse(results_US_ICs$H_F_MDS,results_US_ICs$H)
rmse_value_US_ICs_H

US_ICs_modelled_LE <-ggplot(results_US_ICs, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_ICs")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_ICs_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_ICs_modelled_LE

US_ICs_modelled_H <-ggplot(results_US_ICs, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_ICs")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_ICs_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_ICs_modelled_H

#Save the results
write.csv(results_US_ICs, "Results_US_ICs_all.csv", row.names = FALSE)


#Import data from US_Ivo site
US_Ivo <- read.csv("FLX_US-Ivo_FLUXNET2015_FULLSET_HH_2004-2007_1-4.csv")

US_Ivo <- US_Ivo %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC,H_CORR,LE_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
US_Ivo <- US_Ivo  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

#Set the NA values
US_Ivo <- US_Ivo  %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
US_Ivo <- US_Ivo  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_Ivo$z <- 3.42 
US_Ivo$zveg <- 0.3

# Remove the NA values
US_Ivo_input <- US_Ivo[complete.cases(US_Ivo), ]

#Remove the energy unclosure data
US_Ivo_input <- US_Ivo_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))


# Assign the dataframe for model input
data <-US_Ivo_input

# Modelling using method_ns
results_US_Ivo <-Modelling_method_ns(data)
results_US_Ivo <- cbind(US_Ivo_input,results_US_Ivo)

# remove the NA values in the results
results_US_Ivo <- results_US_Ivo[complete.cases(results_US_Ivo), ]

# Ploting
rmse_value_US_Ivo_LE <-rmse(results_US_Ivo$LE_F_MDS,results_US_Ivo$LE)
rmse_value_US_Ivo_LE

rmse_value_US_Ivo_H <-rmse(results_US_Ivo$H_F_MDS,results_US_Ivo$H)
rmse_value_US_Ivo_H

US_Ivo_modelled_LE <-ggplot(results_US_Ivo, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Ivo")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,750)+xlim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_Ivo_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_Ivo_modelled_LE

US_Ivo_modelled_H <-ggplot(results_US_Ivo, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Ivo")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_Ivo_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_Ivo_modelled_H

#Save the results
write.csv(results_US_Ivo, "Results_US_Ivo_all.csv", row.names = FALSE)


#Import data from US_Los site
US_Los <- read.csv("FLX_US-Los_FLUXNET2015_FULLSET_HH_2000-2014_2-4.csv")

US_Los <- US_Los %>%
  select(
    TIMESTAMP_START,PA_F,PA_F_QC,TA_F,TA_F_QC,WS_F,WS_F_QC,USTAR,RH,NETRAD,G_F_MDS,G_F_MDS_QC,
    LE_F_MDS,LE_F_MDS_QC, H_F_MDS, H_F_MDS_QC, LE_CORR,H_CORR) %>%
  rename(Pressure=PA_F,Ta=TA_F,WS=WS_F,Ustar=USTAR,Rn=NETRAD)

# Remove the worse quality data using the data quality flag
US_Los <- US_Los  %>%
  filter(!(PA_F_QC >1),
         !(TA_F_QC >1),
         !(WS_F_QC >1),
         !(G_F_MDS_QC >1),
         !(LE_F_MDS_QC >1),
         !(H_F_MDS_QC >1))  

#Set the NA values
US_Los <- US_Los %>%
  mutate_all(~na_if(.,-9999))

#Convert the unit
US_Los <- US_Los  %>%
  mutate( Pressure=Pressure*1000,
          Ta = Ta + 273.15,
          RH = RH/100)

US_Los$z <- 10.2
US_Los$zveg <- 2


# Remove the NA values
US_Los_input <- US_Los[complete.cases(US_Los), ]

#Remove the energy unclosure data
US_Los_input <- US_Los_input  %>%
  filter(!(Rn - G_F_MDS - LE_F_MDS - H_F_MDS > 50),
         !(Rn - G_F_MDS < 0))


# Assign the dataframe for model input
data <-US_Los_input

# Modelling using method_ns
results_US_Los <-Modelling_method_ns(data)
results_US_Los <- cbind(US_Los_input,results_US_Los)

# Remove the NA values
results_US_Los <- results_US_Los[complete.cases(results_US_Los), ]

# Ploting
rmse_value_US_Los_LE <-rmse(results_US_Los$LE_F_MDS,results_US_Los$LE)
rmse_value_US_Los_LE

rmse_value_US_Los_H <-rmse(results_US_Los$H_F_MDS,results_US_Los$H)
rmse_value_US_Los_H

US_Los_modelled_LE <-ggplot(results_US_Los, aes(x=LE_F_MDS,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Los")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +xlim(-100,750)+ylim(-100,750)+
  geom_text(x = 53, y = 648, label = paste("RMSE =", round(rmse_value_US_Los_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_Los_modelled_LE

US_Los_modelled_H <-ggplot(results_US_Los, aes(x=H_F_MDS,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="US_Los")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,500)+xlim(-100,500)+
  geom_text(x = 8, y = 428, label = paste("RMSE =", round(rmse_value_US_Los_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
US_Los_modelled_H

#Save the results
write.csv(results_US_Los, "Results_US_Los_all.csv", row.names = FALSE)


# Combining the plots of the rest of the sites, and make Figure 2 and Figure S1.

Model_H_S1 <- plot_grid(CZ_wet_modelled_H,DE_sfN_modelled_H,DE_Zrk_modelled_H,FI_Lom_modelled_H,US_Atq_modelled_H,US_BZB_modelled_H,US_BZF_modelled_H,US_BZo_modelled_H,US_ICs_modelled_H,US_Ivo_modelled_H,US_Los_modelled_H,nrow=3)
Figure_S1_H <- annotate_figure(Model_H_S1, left = textGrob(expression("Modelled H"~(W ~ m^-2)), rot = 90, vjust = 1, gp = gpar(cex = 1.3)),
                               bottom = textGrob(expression("Measured H"~(W~m^-2)), gp = gpar(cex = 1.3)))
ggsave("Figure_S1_H.tiff", device = "tiff",plot=Figure_S1_H, dpi =800, width =16 , height =12,bg="white")

Model_LE_subdaily <- plot_grid(CZ_wet_modelled_LE,DE_sfN_modelled_LE,DE_Zrk_modelled_LE,FI_Lom_modelled_LE,US_Atq_modelled_LE,US_BZB_modelled_LE,US_BZF_modelled_LE,US_BZo_modelled_LE,US_ICs_modelled_LE,US_Ivo_modelled_LE,US_Los_modelled_LE,nrow=3)
Figure_LE_subdaily <- annotate_figure(Model_LE_subdaily, left = textGrob(expression("Modelled LE"~(W~m^-2)), rot = 90, vjust = 1, gp = gpar(cex = 1.3)),
                                      bottom = textGrob(expression("Measured LE"~(W~m^-2)), gp = gpar(cex = 1.3)))
ggsave("Figure_LE_subdaily.tiff", device = "tiff",plot=Figure_LE_subdaily, dpi =800, width =16 , height =12,bg="white")

# Collect the modelled and measured LE and H from all sites
Results_all <- data.frame()

CZ_wet_R <-results_CZ_wet[,c("LE_F_MDS","LE","H_F_MDS","H")]
CZ_wet_R$site <-"CZ_wet"
names(CZ_wet_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,CZ_wet_R)

DE_sfN_R <-results_DE_sfN[,c("LE_F_MDS","LE","H_F_MDS","H")]
DE_sfN_R$site <-"DE_sfN"
names(DE_sfN_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,DE_sfN_R)

DE_Zrk_R <-results_DE_Zrk[,c("LE_F_MDS","LE","H_F_MDS","H")]
DE_Zrk_R$site <-"DE_Zrk"
names(DE_Zrk_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,DE_Zrk_R)

FI_Lom_R <-results_FI_Lom[,c("LE_F_MDS","LE","H_F_MDS","H")]
FI_Lom_R$site <-"FI_Lom"
names(FI_Lom_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,FI_Lom_R)

US_Atq_R <-results_US_Atq[,c("LE_F_MDS","LE","H_F_MDS","H")]
US_Atq_R$site <-"US_Atq"
names(US_Atq_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,US_Atq_R)


US_BZB_R <-results_US_BZB[,c("LE_F_MDS","LE","H_F_MDS","H")]
US_BZB_R$site <-"US_BZB"
names(US_BZB_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,US_BZB_R)

US_BZF_R <-results_US_BZF[,c("LE_F_MDS","LE","H_F_MDS","H")]
US_BZF_R$site <-"US_BZF"
names(US_BZF_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,US_BZF_R)

US_BZo_R <-results_US_BZo[,c("LE_F_MDS","LE","H_F_MDS","H")]
US_BZo_R$site <-"US_BZo"
names(US_BZo_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,US_BZo_R)

US_ICs_R <-results_US_ICs[,c("LE_F_MDS","LE","H_F_MDS","H")]
US_ICs_R$site <-"US_ICs"
names(US_ICs_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,US_ICs_R)

US_Ivo_R <-results_US_Ivo[,c("LE_F_MDS","LE","H_F_MDS","H")]
US_Ivo_R$site <-"US_Ivo"
names(US_Ivo_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,US_Ivo_R)

US_Los_R <-results_US_Los[,c("LE_F_MDS","LE","H_F_MDS","H")]
US_Los_R$site <-"US_Los"
names(US_Los_R) <-c("measured_LE","LE","measured_H","H","site")
Results_all <- rbind(Results_all,US_Los_R)

#Save the results
write.csv(Results_all, "Results_subdaily_no_closure_no_LSP.csv", row.names = FALSE)

rmse_value_results_all_LE <-rmse(Results_all$measured_LE,Results_all$LE)
rmse_value_results_all_LE

rmse_value_results_all_H <-rmse(Results_all$measured_H,Results_all$H)
rmse_value_results_all_H

# Create a scatter plot. The two libraries can only be loaded here, otherwise some functions may contracdict to the functions from other libraries.
library(MASS)
library(viridis)

# The density function was copied from https://slowkow.com/notes/ggplot2-color-by-density/. 
# Get density of points in 2 dimensions.
# @param x A numeric vector.
# @param y A numeric vector.
# @param n Create a square n by n grid to compute density.
# @return The density within each square.
get_density <- function(x, y, ...) {
  dens <- MASS::kde2d(x, y, ...)
  ix <- findInterval(x, dens$x)
  iy <- findInterval(y, dens$y)
  ii <- cbind(ix, iy)
  return(dens$z[ii])
}

Results_all$density_LE <- get_density(Results_all$measured_LE,Results_all$LE,n=100)
Results_all$density_H <- get_density(Results_all$measured_H,Results_all$H,n=100)

Results_all_plot_LE <- ggplot(Results_all, aes(x = measured_LE, y = LE)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_LE))+scale_color_viridis(option="C")+
  labs(title = "Half-hourly", color = "Density")+xlab(expression(LE["obs"])) + ylab("LE")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_value_results_all_LE, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

Results_all_plot_LE

Results_all_plot_H <- ggplot(Results_all, aes(x = measured_H, y = H)) +geom_abline(intercept = 0, slope = 1)+
  geom_point(aes(color = density_H))+scale_color_viridis(option="C")+
  labs(title = "Half-hourly", color = "Density")+xlab(expression(H["obs"])) + ylab("H")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_value_results_all_H, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")

Results_all_plot_H


# Collect all results
Results_subdaily <- data.frame()
Results_subdaily <- rbind(Results_subdaily,results_CZ_wet)
Results_subdaily <- rbind(Results_subdaily,results_DE_sfN)
Results_subdaily <- rbind(Results_subdaily,results_DE_Zrk)
Results_subdaily <- rbind(Results_subdaily,results_FI_Lom)
Results_subdaily <- rbind(Results_subdaily,results_US_Atq)
Results_subdaily <- rbind(Results_subdaily,results_US_BZB)
Results_subdaily <- rbind(Results_subdaily,results_US_BZF)
Results_subdaily <- rbind(Results_subdaily,results_US_BZo)
Results_subdaily <- rbind(Results_subdaily,results_US_ICs)
Results_subdaily <- rbind(Results_subdaily,results_US_Ivo)
Results_subdaily <- rbind(Results_subdaily,results_US_Los)



#Calculate the residual H and residual LE
Results_subdaily$H_residual <- Results_subdaily$Rn - Results_subdaily$G_F_MDS - Results_subdaily$LE_F_MDS
Results_subdaily$LE_residual <- Results_subdaily$Rn - Results_subdaily$G_F_MDS - Results_subdaily$H_F_MDS


#Save the results
write.csv(Results_subdaily, "Results_subdaily_no_theta.csv", row.names = FALSE)


#calculate the RMSE for energy closure corrected energy fluxes and residual energy fluxes
rmse_value_results_LE_CORR <-rmse(Results_subdaily$LE_CORR,Results_subdaily$LE)
rmse_value_results_LE_CORR
rmse_value_results_LE_residual <-rmse(Results_subdaily$LE_F_MDS,Results_subdaily$LE_residual)
rmse_value_results_LE_residual

rmse_value_results_H_CORR <-rmse(Results_subdaily$H_CORR,Results_subdaily$H)
rmse_value_results_H_CORR
rmse_value_results_H_residual <-rmse(Results_subdaily$H_F_MDS,Results_subdaily$H_residual)
rmse_value_results_H_residual


# making graph for energy closure corrected energy fluxes 
modelled_LE_CORR_subdaily <-ggplot(Results_subdaily, aes(x=LE_CORR,y=LE)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="Half-hourly (energy closure corrected)")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +xlim(-100,850)+ylim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_value_results_LE_CORR, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
modelled_LE_CORR_subdaily

modelled_H_CORR_subdaily <-ggplot(Results_subdaily, aes(x=H_CORR,y=H)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="Half-hourly (energy closure corrected)")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_value_results_H_CORR, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
modelled_H_CORR_subdaily

# making graph for measured fluxes versus the energy balance residual (upper bound of the mdoel performance) 
modelled_LE_RE_subdaily <-ggplot(Results_subdaily, aes(x=LE_F_MDS,y=LE_residual)) +
  geom_point(size=1,color="lightgreen")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="Half-hourly (upper bound)")+stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +xlim(-100,850)+ylim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_value_results_LE_residual, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
modelled_LE_RE_subdaily

modelled_H_RE_subdaily <-ggplot(Results_subdaily, aes(x=H_F_MDS,y=H_residual)) +
  geom_point(size=1,color="hotpink")+ geom_abline(intercept = 0, slope = 1)+
  labs(title="Half-hourly (upper bound)")+
  stat_poly_line() +stat_poly_eq(use_label(c("eq", "R2"))) +ylim(-100,850)+xlim(-100,850)+
  geom_text(x = 71, y = 736, label = paste("RMSE =", round(rmse_value_results_H_residual, 2)), size = 3.8, color = "blue") +  # Add RMSE
  theme_bw()+
  theme(
    plot.title = element_text(size=10),
    axis.text = element_text(size = 10),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"),
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(face = "bold"),
    axis.title.x=element_blank(),
    axis.title.y=element_blank(),
    panel.grid=element_blank(),
    panel.border = element_rect(colour = "black", size=1.6),
    axis.ticks = element_line(size = 1.6),
    legend.position ="none")
modelled_H_RE_subdaily



