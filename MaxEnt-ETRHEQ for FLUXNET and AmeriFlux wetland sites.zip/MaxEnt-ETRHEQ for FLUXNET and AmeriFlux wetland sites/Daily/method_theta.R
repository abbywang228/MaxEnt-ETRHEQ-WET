# This method requires soil moisture. 
# This method generates a series of Ts and RHs, and finds the best combination of Ts and RHs that leads to the minimum dissipation (D)

Modelling_method_theta <-function(data){
  # Create a new data frame for the best results
  best_results <- data.frame(RHs = numeric(nrow(data)), Ts = numeric(nrow(data)),H = numeric(nrow(data)), LE = numeric(nrow(data)))
  
  # Create a function to calculate D for a given pair of RHs and Ts
  calculate_D <- function(Ts, RHs, p, Ta, u, ustar, RH, Rn, z, zveg, theta) {
    #Define constants:
    epsilon <- 0.622 #the dimensionless ratio of the gas constant for dry air to water vapor
    cp <- 1004.7 #the specific heat of air at constant pressure (J·kg−1·°C−1),
    lambda <- 2.502 * 10^6 #the latent heat of vaporization (J·kg−1).
    g <- 9.81 #the gravitational acceleration (m·s−2),
    Rd <- 287 #gas constant for dry air (J·kg−1·K−1)
    k <- 0.41 #von Karman constant
    gamma <- cp/lambda
    
    ps <- p / exp(-g * z / (Rd * Ta))
    rho <- p / (Rd * Ta)
    estar_Ts <- 611.2 * exp(17.67 * (Ts - 273.15) / (Ts - 29.65))
    qstar_Ts <- epsilon * estar_Ts / (ps - (1 - epsilon) * estar_Ts)
    estar_T <- 611.2 * exp(17.67 * (Ta - 273.15) / (Ta - 29.65))
    qstar_T <- epsilon * estar_T / (p - (1 - epsilon) * estar_T)
    delta <- (qstar_Ts - qstar_T) / (Ts - Ta)
    if(zveg==0){
      zoh <-0.001
      zom <-0.001
      ra <-log(z/zoh)*log(z/zom)/((k^2)*u)
    }else{
      zom <- 0.1 * zveg
      Re <- ustar * zom / (1.45E-5)
      zoh <- zom / exp(k * (6 * Re^(1/4) - 5))
      d <- 0.7 * zveg
      ra <- (log((z - d) / zom) * log((z - d) / zoh)) / ((k^2) * u)
    }
    Ri <- (5 * g * z * (Ts - Ta)) / (Ta * (u^2))
    eta <- ifelse(Ts > Ta, 0.75, 2)
    rah <- ra / ((1 + Ri)^eta)
    ga <- 1 / rah
    H <- rho * cp * ga * (Ts - Ta)
    LE <- lambda*rho*ga*(RHs*qstar_Ts-RH*qstar_T)
    G <- Rn - LE - H
    G_limit <- 0.20*Rn
    gamma_PM <- cp*p/(0.622*lambda)
    delta_PM <- 1000*4098*(0.6108*exp(17.27*(Ta-273.15)/((Ta-273.15)+237.3)))/((Ta-273.15+237.3)^2)
    RHs_limit <-1.26*gamma_PM*lambda/(delta*(1-1.26*lambda)+gamma_PM)
    
    if (!is.na(H) && is.numeric(LE) && is.numeric(G) && RHs >=RHs_limit && G<=G_limit) {
      Is <- sqrt(800^2+theta*1557^2)
      Ia <- rho * cp * sqrt(ga)
      Ie <- delta / gamma * RHs * Ia
      D <- 2 * (G^2) / Is + 2 * (H^2) / Ia + 2 * (LE^2) / Ie
      return(list(D = D, RHs=RHs,Ts=Ts,H = H, LE = LE))
      
    } else {
      return(list(D=9999, RHs=RHs,Ts=Ts,H=H,LE=LE))
      
    }
    
    
  }
  
  # Loop through rows and find the best RHs and Ts for each row
  for (i in 1:nrow(data)) {
    row_data <- data[i, ]
    # Create a sequence of Ts and RHs
    Ts_range <- seq(row_data$Ta-30, row_data$Ta + 30, 0.1)
    RHs_range <- seq(row_data$RH, 1, 0.1)
    
    # Create all combinations of Ts and RHs
    combinations <- expand.grid(Ts = Ts_range, RHs = RHs_range)
    
    # Calculate D for all combinations
    results <- pmap(list(combinations$Ts, combinations$RHs, row_data$Pressure, row_data$Ta, row_data$WS, row_data$Ustar, row_data$RH ,row_data$Rn, row_data$z, row_data$zveg, row_data$theta), 
                    ~ calculate_D(..1, ..2, ..3, ..4, ..5, ..6, ..7, ..8, ..9, ..10, ..11))
    
    # Find the best pair of Ts and RHs that lead to the minimum D for this row
    best_combination_index <- which.min(map_dbl(results, "D"))
    best_combination <- combinations[best_combination_index, ]
    
    # Assign the best RHs and Ts to the best_results data frame
    best_results$Ts[i] <- best_combination$Ts
    
    # Retrieve the values from the calculate_D result
    D_values <- results[[best_combination_index]]
    best_results$RHs[i] <- D_values$RHs
    best_results$H[i] <- D_values$H
    best_results$LE[i] <- D_values$LE
  }
  
  return(best_results)
}
