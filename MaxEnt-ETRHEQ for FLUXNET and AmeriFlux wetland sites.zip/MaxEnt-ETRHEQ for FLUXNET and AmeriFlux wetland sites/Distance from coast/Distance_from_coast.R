# Load library
library(ggOceanMaps) # in order to use its function dis2land, the output are in kilometers.
library(rnaturalearth)
library(sf)

# Load coastline data
coast <- ne_coastline(scale=10, returnclass = "sf")

# Load the study site coordinates
Global_sites <- read.csv("Global_sites.csv")

# Calculate the shortest distance
ggOceanMaps::dist2land(Global_sites,shapefile =coast)


