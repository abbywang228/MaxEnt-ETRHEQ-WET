install.packages("ecmwfr")
install.packages("ncdf4")
install.packages("tidyverse")

library(ecmwfr)
library(ncdf4)
library(tidyverse)

getwd()  # Check the current working directory where downloaded data will be saved

wf_set_key(key = "Your key") # Set ECMWF API key (provided upon registration with the ECMWF data service)

#CZ-wet
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2006:2014),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(49.0246, 14.7704, 49.0247, 14.7704), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file for CZ-wet site
nc_data <- nc_open("ecmwfr_6fe82c3f40ae.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_cz_wet_ustar.csv", row.names = FALSE)  # Save as CSV


#DE-sfN
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2012:2014),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(47.8064, 11.3274, 47.8063, 11.3275), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ecmwfr_6fe83f471ae8.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_DE_sfN_ustar.csv", row.names = FALSE)  # Save as CSV

#DE-Zrk
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2013:2014),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(53.8759, 12.888, 53.8758, 12.889), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ecmwfr_6fe8c8b327c.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_DE_Zrk_ustar.csv", row.names = FALSE)  # Save as CSV

#FI-Lom
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2007:2009),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(67.9972, 24.2091, 67.9971, 24.2092), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ecmwfr_6fe87c417049.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_FI_lom_ustar.csv", row.names = FALSE)  # Save as CSV


#US-Atq
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2003:2008),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(70.4696, -157.4090, 70.4695, -157.4089), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ecmwfr_6fe81d172df0.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_Atq_ustar.csv", row.names = FALSE)  # Save as CSV

#US-BZB
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2011:2021),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(64.6955, -148.3209, 64.6954, -148.3208), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("b7621569faa27ab7c20d70a95acbb70a.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_BZB_ustar.csv", row.names = FALSE)  # Save as CSV


#US-BZF
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2011:2021),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(64.7013, -148.3121,64.7012, -148.3120), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)

wf_transfer(
  url = 'https://cds.climate.copernicus.eu/api/retrieve/v1/jobs/2dafee15-6563-43d2-b694-b406208287ae',
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download',
  filename = ''
)

# Load NetCDF file
nc_data <- nc_open("9a8bdffebed00fc965e2155746c78381.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_BZF_ustar.csv", row.names = FALSE)  # Save as CSV

#US-BZo
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2018:2021),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(64.6936, -148.33,64.6935, -148.32), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ecmwfr_6b847d312329.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_BZo_ustar.csv", row.names = FALSE)  # Save as CSV

#US-ICs (part 1)
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2007:2015),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(68.6058, -149.311, 68.6057, -149.310), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("f76d9318463a76cb3c361c5a2d06a153.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_ICs_ustar_1.csv", row.names = FALSE)  # Save as CSV


#US-ICs (part 2)
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2016:2020),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(68.6058, -149.311, 68.6057, -149.310), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ecmwfr_6b84da52c.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_ICs_ustar_2.csv", row.names = FALSE)  # Save as CSV


#US-Ivo
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2004:2007),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(68.4865, -155.7503, 68.4864, -155.7502), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ecmwfr_50d48d76044.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_Ivo_ustar.csv", row.names = FALSE)  # Save as CSV


#US-Los (Part1)
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2000:2007),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(46.0827, -89.9792, 46.0826, -89.9791), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("ba5e471b7ed7ac13ea714d8d53d95713.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_Los_ustar_1.csv", row.names = FALSE)  # Save as CSV

#US-Los (Part2)
request <- wf_request(
  request = list(
    "dataset_short_name" = "reanalysis-era5-single-levels",
    "product_type" = "reanalysis",
    "variable" = "friction_velocity",
    "year" = as.character(2008:2014),
    "month" = sprintf("%02d", 1:12),
    "day" = sprintf("%02d", 1:31),
    "time" = sprintf("%02d:00", 0:23),  # Hourly data
    "area" = c(46.0827, -89.9792, 46.0826, -89.9791), #north, west, south, east
    "format" = "netcdf"
  ),
  transfer = TRUE,
  path = 'C:/Users/abbyw/Documents/R/ERA_data_download'  # Use a valid directory
)


# Load NetCDF file
nc_data <- nc_open("9c1b784dfd7514e3d8251f4294204f92.nc")

#List all available variables
print(nc_data$var)
print(nc_data$dim)  # Lists all dimensions

#the time variable is labeled as "valid_time", and friction velocity is stored as "zust".


# Extract time values
time <- ncvar_get(nc_data, "valid_time")  # Extract time
timestamp <- as.POSIXct(time, origin = "1970-01-01", tz = "UTC")  # Convert to readable format

# Format timestamp as "YYYY-MM-DD HH:MM:SS AM/PM"
timestamp <- format(timestamp, "%Y-%m-%d %I:%M:%S %p")

# Extract ustar data
ustar <- ncvar_get(nc_data, "zust")  # Extract friction velocity


# Close the NetCDF file
nc_close(nc_data)

# Convert to dataframe
df <- tibble(timestamp = timestamp, ustar = ustar)

df <- as.data.frame(df)  # Convert tibble to data.frame
write.csv(df, "era5_US_Los_ustar_2.csv", row.names = FALSE)  # Save as CSV
